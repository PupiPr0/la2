document.addEventListener("DOMContentLoaded", function() {
    const newsContainer = document.getElementById('news-container');

    fetch('https://news-api-la2.wildmoney.pro/')
        .then(response => response.json())
        .then(data => {
            if (!data.error) {
                data.items.forEach(item => {
                    const newsItem = document.createElement('div');
                    newsItem.classList.add('news-item');
                    newsItem.innerHTML = `
                        <h3>${item.fromUserFullname} - ${item.date}</h3>
                        <p>${item.post}</p>
                        ${item.imgUrl ? `<img src="${item.imgUrl}" alt="News Image">` : ''}
                    `;
                    newsContainer.appendChild(newsItem);
                });
            } else {
                newsContainer.innerHTML = '<p>Не удалось загрузить новости.</p>';
            }
        })
        .catch(error => {
            console.error('Ошибка:', error);
            newsContainer.innerHTML = '<p>Произошла ошибка при загрузке новостей.</p>';
        });
});
